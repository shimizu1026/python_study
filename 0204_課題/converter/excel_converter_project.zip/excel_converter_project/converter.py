"""
Excel変換ロジック
入力ファイルを読み込み、指定のフォーマットに変換する
"""

import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


class ExcelConverter:
    """Excelデータ変換クラス"""
    
    def __init__(self):
        """初期化"""
        self.input_data = None
        self.output_wb = None
        
    def convert(self, input_path, output_path):
        """
        メイン変換処理
        
        Parameters:
        -----------
        input_path : str
            入力ファイルのパス
        output_path : str
            出力ファイルのパス
        """
        # 1. 入力ファイルを読み込む
        print(f"入力ファイルを読み込んでいます: {input_path}")
        self.input_data = self.read_input_file(input_path)
        
        # 2. 出力用のワークブックを作成
        print("出力フォーマットを作成しています...")
        self.output_wb = self.create_output_workbook()
        
        # 3. データを変換して出力ワークブックに書き込む
        print("データを変換しています...")
        self.transform_data()
        
        # 4. ファイルを保存
        print(f"出力ファイルを保存しています: {output_path}")
        self.output_wb.save(output_path)
        print("変換完了！")
        
    def read_input_file(self, input_path):
        """
        入力ファイルを読み込む
        
        Parameters:
        -----------
        input_path : str
            入力ファイルのパス
            
        Returns:
        --------
        pandas.DataFrame
            読み込んだデータ
        """
        # ヘッダー行が7行目（0-indexedで6）にあるため、header=7で読み込む
        df = pd.read_excel(input_path, sheet_name='組立部品リスト', header=7)
        
        print(f"データを読み込みました: {len(df)} 行, {len(df.columns)} 列")
        return df
        
    def create_output_workbook(self):
        """
        出力用のワークブックを作成
        
        Returns:
        --------
        openpyxl.Workbook
            作成されたワークブック
        """
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "変換結果"
        
        # ヘッダー行を作成
        headers = [
            'Order名', '', '', 'Order＃', '', '', 
            'Item＃', '', '', 'Item名称', '', '', '', '', '', '',
            'ｄ', '', '', '',
            'Ds', '', '', '',
            'Dm', '', '', '',
            'De', '', '', '',
            'PD', '', '', ''
        ]
        
        # ヘッダーを書き込む
        for col_idx, header in enumerate(headers, start=1):
            ws.cell(row=1, column=col_idx, value=header)
        
        # 2行目にサブヘッダー
        sub_headers = [''] * 16  # 最初の16列は空
        categories = ['部品数', '重量'] * 5  # d, Ds, Dm, De, PDの各2列
        sub_headers.extend(categories)
        
        for col_idx, sub_header in enumerate(sub_headers, start=1):
            ws.cell(row=2, column=col_idx, value=sub_header)
        
        # ヘッダーのスタイルを設定
        self.apply_header_style(ws)
        
        return wb
        
    def apply_header_style(self, ws):
        """
        ヘッダー行にスタイルを適用
        
        Parameters:
        -----------
        ws : openpyxl.worksheet.worksheet.Worksheet
            ワークシート
        """
        # ヘッダー用のスタイル
        header_font = Font(bold=True, size=11)
        header_fill = PatternFill(start_color='CCCCCC', end_color='CCCCCC', fill_type='solid')
        header_alignment = Alignment(horizontal='center', vertical='center')
        border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        
        # 1行目と2行目にスタイルを適用
        for row in range(1, 3):
            for col in range(1, 36):
                cell = ws.cell(row=row, column=col)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = header_alignment
                cell.border = border
        
    def transform_data(self):
        """
        データを変換して出力ワークブックに書き込む
        """
        ws = self.output_wb.active
        current_row = 3  # データは3行目から開始
        
        # 入力データからOrder名、Order#、Item#、Item名称を抽出
        # ※ここでは簡易実装として、最初の数行のみ変換
        for idx, row in self.input_data.head(20).iterrows():
            try:
                # ITEMカラムからOrder名とOrder#を取得（実際のデータ構造に応じて調整が必要）
                order_name = "TNPR"  # 仮の値
                order_num = "1021K457"  # 仮の値
                item_num = str(row.get('ITEM', '')).split('.')[0] if pd.notna(row.get('ITEM')) else ''
                item_name = str(row.get('SERIAL', '')) if pd.notna(row.get('SERIAL')) else ''
                
                # データを書き込む
                ws.cell(row=current_row, column=1, value=order_name)
                ws.cell(row=current_row, column=4, value=order_num)
                ws.cell(row=current_row, column=7, value=item_num)
                ws.cell(row=current_row, column=10, value=item_name)
                
                # カテゴリ別の部品数と重量は後で計算ロジックを追加
                # 現時点では0で初期化
                for col in range(17, 36, 2):
                    ws.cell(row=current_row, column=col, value=0)  # 部品数
                    ws.cell(row=current_row, column=col+1, value=0.0)  # 重量
                
                current_row += 1
                
            except Exception as e:
                print(f"Row {idx} でエラー: {str(e)}")
                continue
        
        # 列幅を調整
        for col in range(1, 36):
            ws.column_dimensions[get_column_letter(col)].width = 12


# テスト用コード（このファイルを直接実行した場合のみ動作）
if __name__ == "__main__":
    converter = ExcelConverter()
    # テスト実行
    # converter.convert('test_input.xlsx', 'test_output.xlsx')
    print("converter.py が読み込まれました")
