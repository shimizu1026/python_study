"""
Excel データ変換システム
ローカルPC内で動作する、Excelファイルのフォーマット変換アプリケーション
"""

from flask import Flask, render_template, request, send_file, jsonify
import os
from werkzeug.utils import secure_filename
from converter import ExcelConverter

# Flaskアプリケーションの初期化
app = Flask(__name__)

# 設定
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['OUTPUT_FOLDER'] = 'outputs'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 最大16MBまで
app.config['ALLOWED_EXTENSIONS'] = {'xlsx', 'xls'}

# フォルダが存在しない場合は作成
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)


def allowed_file(filename):
    """アップロード可能なファイルかチェック"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


@app.route('/')
def index():
    """トップページを表示"""
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload_file():
    """ファイルをアップロードして変換を実行"""
    try:
        # ファイルがアップロードされているかチェック
        if 'file' not in request.files:
            return jsonify({'error': 'ファイルが選択されていません'}), 400
        
        file = request.files['file']
        
        # ファイル名が空でないかチェック
        if file.filename == '':
            return jsonify({'error': 'ファイルが選択されていません'}), 400
        
        # ファイル形式が正しいかチェック
        if not allowed_file(file.filename):
            return jsonify({'error': '対応していないファイル形式です（.xlsx または .xls のみ）'}), 400
        
        # ファイル名を安全な形式に変換して保存
        filename = secure_filename(file.filename)
        input_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(input_path)
        
        # 出力ファイル名を生成
        output_filename = f"converted_{filename}"
        output_path = os.path.join(app.config['OUTPUT_FOLDER'], output_filename)
        
        # 変換処理を実行
        converter = ExcelConverter()
        converter.convert(input_path, output_path)
        
        # 変換成功
        return jsonify({
            'success': True,
            'message': '変換が完了しました',
            'download_url': f'/download/{output_filename}'
        })
        
    except Exception as e:
        # エラーが発生した場合
        return jsonify({'error': f'エラーが発生しました: {str(e)}'}), 500


@app.route('/download/<filename>')
def download_file(filename):
    """変換後のファイルをダウンロード"""
    try:
        file_path = os.path.join(app.config['OUTPUT_FOLDER'], filename)
        return send_file(file_path, as_attachment=True)
    except Exception as e:
        return jsonify({'error': f'ダウンロードエラー: {str(e)}'}), 500


if __name__ == '__main__':
    # 開発用サーバーを起動（ローカルPCでのみアクセス可能）
    print("=" * 60)
    print("Excel データ変換システム を起動しています...")
    print("ブラウザで以下のURLにアクセスしてください:")
    print("http://127.0.0.1:5000")
    print("終了するには Ctrl+C を押してください")
    print("=" * 60)
    app.run(debug=True, host='127.0.0.1', port=5000)
