# Excel データ変換システム

ローカルPC内で動作する、Excelファイルのフォーマット変換システムです。

## 📋 機能

- Webブラウザからファイルをドラッグ＆ドロップでアップロード
- 指定されたルールに基づいてデータを変換
- 変換後のExcelファイルをダウンロード

## 🚀 セットアップ方法

### 1. PyCharmでプロジェクトを開く

1. PyCharmを起動
2. `File` → `Open` を選択
3. `excel_converter_project` フォルダを選択

### 2. 仮想環境の作成（推奨）

PyCharmのターミナルで以下を実行：

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac/Linux
python3 -m venv venv
source venv/bin/activate
```

### 3. 必要なライブラリをインストール

```bash
pip install -r requirements.txt
```

## 💻 使い方

### 1. サーバーを起動

PyCharmでapp.pyを開いて実行するか、ターミナルで：

```bash
python app.py
```

以下のようなメッセージが表示されます：

```
============================================================
Excel データ変換システム を起動しています...
ブラウザで以下のURLにアクセスしてください:
http://127.0.0.1:5000
終了するには Ctrl+C を押してください
============================================================
```

### 2. ブラウザでアクセス

ブラウザで `http://127.0.0.1:5000` を開きます

### 3. ファイルをアップロード

- ファイルをドラッグ＆ドロップ、または
- エリアをクリックしてファイルを選択

### 4. 変換を実行

「変換を開始」ボタンをクリック

### 5. ファイルをダウンロード

変換が完了したら「ファイルをダウンロード」ボタンが表示されます

## 📁 プロジェクト構造

```
excel_converter_project/
├── app.py              # メインアプリケーション
├── converter.py        # 変換ロジック
├── requirements.txt    # 必要なライブラリ
├── README.md          # このファイル
├── templates/
│   └── index.html     # Webインターフェース
├── static/            # 静的ファイル（CSS、JSなど）
├── uploads/           # アップロードされたファイルの一時保存先
└── outputs/           # 変換後のファイルの保存先
```

## 🔧 トラブルシューティング

### ポート5000が使用中の場合

app.pyの最後の行を編集：

```python
app.run(debug=True, host='127.0.0.1', port=8000)  # 5000 → 8000に変更
```

### ライブラリのインストールに失敗する場合

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### ファイルのアップロードに失敗する場合

- ファイルサイズが16MB以下であることを確認
- ファイル形式が .xlsx または .xls であることを確認

## 📝 注意事項

- このシステムはローカルPC内でのみ動作します
- アップロードされたファイルは`uploads`フォルダに一時保存されます
- 変換後のファイルは`outputs`フォルダに保存されます

## 🔄 変換ロジックのカスタマイズ

変換ルールを変更する場合は、`converter.py`の以下のメソッドを編集してください：

- `read_input_file()`: 入力ファイルの読み込み方法
- `transform_data()`: データの変換ロジック
- `create_output_workbook()`: 出力フォーマットの定義
